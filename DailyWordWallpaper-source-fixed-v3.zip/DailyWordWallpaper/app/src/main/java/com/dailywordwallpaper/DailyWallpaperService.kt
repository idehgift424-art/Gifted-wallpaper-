package com.dailywordwallpaper

import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint
import android.graphics.LinearGradient
import android.graphics.Shader
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import kotlin.math.min

class DailyWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = VerseEngine()

    private inner class VerseEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private var index = getSharedPreferences("daily_word_settings", MODE_PRIVATE)
            .getInt("selected_wallpaper_index", 0).coerceIn(0, wallpaperVerseData.lastIndex)
        private var visible = false
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rotate = object : Runnable {
            override fun run() {
                if (!visible) return
                index = (index + 1) % wallpaperVerseData.size
                drawFrame()
                val minutes = getSharedPreferences("daily_word_settings", MODE_PRIVATE)
                    .getInt("rotation_interval_minutes", 5).coerceIn(5, 15)
                handler.postDelayed(this, minutes * 60_000L)
            }
        }

        override fun onVisibilityChanged(isVisible: Boolean) {
            visible = isVisible
            handler.removeCallbacks(rotate)
            if (visible) {
                drawFrame()
                val minutes = getSharedPreferences("daily_word_settings", MODE_PRIVATE)
                    .getInt("rotation_interval_minutes", 5).coerceIn(5, 15)
                handler.postDelayed(rotate, minutes * 60_000L)
            }
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            drawFrame()
        }

        override fun onDestroy() {
            handler.removeCallbacks(rotate)
            super.onDestroy()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visible = false
            handler.removeCallbacks(rotate)
            super.onSurfaceDestroyed(holder)
        }

        private fun drawFrame() {
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas()
                if (canvas != null) render(canvas)
            } finally {
                if (canvas != null) holder.unlockCanvasAndPost(canvas)
            }
        }

        private fun render(canvas: Canvas) {
            index = index.coerceIn(0, wallpaperVerseData.lastIndex)
            val item = wallpaperVerseData[index]
            paint.shader = LinearGradient(0f, 0f, canvas.width.toFloat(), canvas.height.toFloat(),
                item.startColor, item.endColor, Shader.TileMode.CLAMP)
            canvas.drawRect(0f, 0f, canvas.width.toFloat(), canvas.height.toFloat(), paint)
            paint.shader = null
            paint.color = AndroidColor.WHITE
            paint.textAlign = Paint.Align.CENTER
            paint.textSize = min(canvas.width, canvas.height) * 0.027f
            paint.alpha = 210
            canvas.drawText("DAILY WORD", canvas.width / 2f, canvas.height * 0.39f, paint)

            paint.textSize = min(canvas.width, canvas.height) * 0.047f
            paint.alpha = 255
            val lines = wrapText(item.verse, paint, canvas.width * 0.78f)
            val lineHeight = paint.textSize * 1.35f
            val startY = canvas.height / 2f - (lines.size - 1) * lineHeight / 2f
            lines.forEachIndexed { i, line -> canvas.drawText(line, canvas.width / 2f, startY + i * lineHeight, paint) }

            paint.textSize = min(canvas.width, canvas.height) * 0.024f
            canvas.drawText(item.reference, canvas.width / 2f, canvas.height * 0.62f, paint)
        }

        private fun wrapText(text: String, paint: Paint, maxWidth: Float): List<String> {
            val result = mutableListOf<String>()
            var line = ""
            text.split(" ").forEach { word ->
                val candidate = if (line.isEmpty()) word else "$line $word"
                if (paint.measureText(candidate) > maxWidth && line.isNotEmpty()) {
                    result.add(line); line = word
                } else line = candidate
            }
            if (line.isNotEmpty()) result.add(line)
            return result
        }
    }
}

private data class WallpaperVerse(val verse: String, val reference: String, val startColor: Int, val endColor: Int)
private val wallpaperVerseData = listOf(
    WallpaperVerse("The Lord is my shepherd; I shall not want.", "Psalm 23:1 · KJV", 0xFF172B4D.toInt(), 0xFF527A9A.toInt()),
    WallpaperVerse("Peace I leave with you, my peace I give unto you.", "John 14:27 · KJV", 0xFF123B45.toInt(), 0xFF397C78.toInt()),
    WallpaperVerse("I can do all things through Christ which strengtheneth me.", "Philippians 4:13 · KJV", 0xFF33234F.toInt(), 0xFF765B91.toInt()),
    WallpaperVerse("His compassions fail not. They are new every morning.", "Lamentations 3:22–23 · KJV", 0xFF563C32.toInt(), 0xFFB36C4D.toInt())
)
